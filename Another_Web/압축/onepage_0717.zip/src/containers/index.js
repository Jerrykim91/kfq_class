import PostingContainer from "./postingContainer/PostingContainer";

// 객체를 모듈화
export {
    PostingContainer
}